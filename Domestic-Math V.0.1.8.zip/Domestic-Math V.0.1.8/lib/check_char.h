#define or ||
#define OR ||

//NO_CAPITAL ALPHABET CHECKER.

int ch_char(char ch){
if(ch == 'a' or ch == 'b' or ch == 'c' or ch == 'd' or ch == 'e' or ch == 'f' or ch == 'g' or ch == 'h' or ch == 'i' or ch == 'j' or ch == 'k' or ch == 'l' or ch == 'm' or ch == 'n' or ch == 'o' or ch == 'p' or ch == 'q' or ch == 'r' or ch == 's' or ch == 't' or ch == 'u' or ch == 'v' or ch == 'w' or ch == 'x' or ch == 'y' or ch == 'z'){
    return 1;
}
else{
    return 0;
}
}