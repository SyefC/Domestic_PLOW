//END OF STATEMENT CHECKER

int _check_eos(char c){
if(c == ';'){
    return 1;
}
else{
    return 0;
}
}