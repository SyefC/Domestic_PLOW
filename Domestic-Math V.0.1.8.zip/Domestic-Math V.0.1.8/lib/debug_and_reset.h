void debugnreset(){
if(ok == 1){
    printf("results: %d\n", new);
        if(checkwhitespace(get_value[clear_check])){
            printf("captured flag~\n");
            final_results = 0;
            results = 0;
        exponent = 1;
    int lengh = sizeof(calculate) / sizeof(calculate[0]);
        for(int reset = 0; reset < lengh; reset++){
     calculate[reset] = 0;
        }
    }
    }
    int lenght = sizeof(calculate) / sizeof(calculate[0]);
 for(int check = 0; check < lenght; check++){
    printf("after reset: %d\n", calculate[check]);
 }
}